const kDefaultPadding = 16.0;
